const mysql = require('mysql2');

// إنشاء اتصال بقاعدة البيانات
const db = mysql.createConnection({
  host: 'localhost', // العنوان المحلي
  user: 'root', // اسم المستخدم الخاص بـ MySQL
  password: '', // كلمة المرور (اتركها فارغة إذا كنت لا تستخدم كلمة مرور)
  database: 'tasksDB' // اسم قاعدة البيانات
});

// التحقق من الاتصال
db.connect((err) => {
  if (err) {
    console.error('خطأ أثناء الاتصال بقاعدة البيانات:', err);
    return;
  }
  console.log('تم الاتصال بقاعدة البيانات بنجاح');
});

module.exports = db;
