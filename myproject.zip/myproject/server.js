const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const PORT = 3000;

// تفعيل قراءة بيانات JSON
app.use(express.json());

// إعداد الاتصال بقاعدة البيانات
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // اسم المستخدم
  password: 'AL2882018zayem@', // كلمة المرور الخاصة بـ MySQL
  database: 'tasksDB' // اسم قاعدة البيانات
});

// التحقق من اتصال قاعدة البيانات
db.connect((err) => {
  if (err) {
    console.error('خطأ في الاتصال بقاعدة البيانات:', err);
  } else {
    console.log('تم الاتصال بقاعدة البيانات بنجاح');
  }
});

// مسار الصفحة الرئيسية (اختياري)
app.get('/', (req, res) => {
  res.send('السيرفر يعمل بنجاح!');
});

// مسار تسجيل الدخول
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  const query = 'SELECT * FROM users WHERE username = ? AND password = ?';
  db.query(query, [username, password], (err, results) => {
    if (err) {
      console.error('خطأ في استعلام تسجيل الدخول:', err);
      res.status(500).send('حدث خطأ في السيرفر');
    } else if (results.length > 0) {
      res.json({ success: true, user: results[0] });
    } else {
      res.json({ success: false, message: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
    }
  });
});

// مسار استرجاع المهام
app.get('/tasks', (req, res) => {
  const userId = req.query.userId;

  const query = 'SELECT * FROM tasks WHERE user_id = ?';
  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('خطأ في استعلام المهام:', err);
      res.status(500).send('حدث خطأ في السيرفر');
    } else {
      res.json(results);
    }
  });
});

// تشغيل السيرفر
app.listen(PORT, () => {
  console.log(`السيرفر يعمل على http://localhost:${PORT}`);
});
